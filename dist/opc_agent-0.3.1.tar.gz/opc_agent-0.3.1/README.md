<div align="center">

# 🤖 OPC Agent

### Your 100% Local AI Agent — Zero Cloud, Zero Cost, Total Privacy

### 纯本地 AI Agent — 零云依赖、零成本、完全隐私

[![PyPI version](https://img.shields.io/pypi/v/opc-agent.svg)](https://pypi.org/project/opc-agent/)
[![Downloads](https://img.shields.io/pypi/dm/opc-agent.svg)](https://pypi.org/project/opc-agent/)
[![GitHub stars](https://img.shields.io/github/stars/deepleaper/opc-agent.svg)](https://github.com/deepleaper/opc-agent/stargazers)
[![License](https://img.shields.io/badge/License-BSL--1.1-blue.svg)](LICENSE)
[![Python](https://img.shields.io/badge/Python-3.10+-blue.svg)](https://python.org)

[Website](https://www.deepleaper.com) · [Quick Start](#-quick-start) · [Docs](#-usage) · [vs Leaper Agent](#-opc-agent-vs-leaper-agent)

</div>

---

## ✨ Why OPC Agent? / 为什么选 OPC Agent？

**OPC Agent** is a fully local AI agent powered by [Ollama](https://ollama.com). No API keys, no cloud, no subscriptions. Your data never leaves your machine — and the agent **gets smarter** over time with built-in [DeepBrain](https://github.com/deepleaper/opc-deepbrain) memory.

- 🔒 **100% Local** — Runs entirely on your Mac, PC, or Linux. No internet required after setup.
- 💰 **Zero Cost** — No API fees, no subscriptions. Just your hardware.
- 🧠 **Self-Learning Memory** — Built-in DeepBrain 6-layer memory. Your agent remembers and evolves.
- 🛡️ **Privacy First** — Your conversations, your data, your machine. Period.
- ⚡ **Simple Setup** — `pip install` + `ollama pull` = ready to go.

## 🚀 Quick Start

### Prerequisites

- Python 3.10+
- [Ollama](https://ollama.com) installed and running

### Install & Run

```bash
# 1. Install OPC Agent
pip install opc-agent

# 2. Pull a model via Ollama
ollama pull llama3.1

# 3. Initialize
opc-agent init

# 4. Start chatting!
opc-agent chat
```

That's it. No API keys. No config files. No cloud accounts. 就这么简单。

## 🧠 Built-in DeepBrain Memory

OPC Agent includes [DeepBrain](https://github.com/deepleaper/opc-deepbrain) — a 6-layer self-evolving knowledge engine:

```
⚡ Flash → 📝 Short-Term → 📚 Long-Term → 🏗️ Consolidated → 🗄️ Archived → 🔮 Meta
```

Your agent automatically:
- **Remembers** key facts from conversations
- **Consolidates** patterns across sessions
- **Promotes** validated knowledge to long-term storage
- **Evolves** its understanding over time

All stored in a local SQLite database. No cloud sync. No data leakage.

## 📖 Usage

```bash
# Interactive chat
opc-agent chat

# Chat with a specific model
opc-agent chat --model mistral

# View memory stats
opc-agent brain stats

# Search agent memory
opc-agent brain search "project deadlines"

# Reset memory (careful!)
opc-agent brain reset
```

### Configuration

```bash
# Config location
~/.opc-agent/config.yaml
```

```yaml
model: llama3.1
memory:
  enabled: true
  db_path: ~/.opc-agent/brain.db
  auto_learn: true
```

## ⚖️ OPC Agent vs Leaper Agent

| | OPC Agent | Leaper Agent |
|---|-----------|-------------|
| **LLM** | Ollama (local models) | OpenAI / Claude / Gemini |
| **Internet Required** | No | Yes (API calls) |
| **Cost** | $0 | Pay-per-token |
| **Privacy** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ |
| **Model Quality** | Good (local models) | Best (GPT-4, Claude 3.5) |
| **Multi-Agent** | ❌ | ✅ |
| **Telegram Bot** | ❌ | ✅ |
| **Best For** | Privacy, offline, zero-cost | Power users, teams, integrations |

**Want cloud models?** → Check out [Leaper Agent](https://github.com/deepleaper/leaper-agent)
**在中国？** → Check out [Leaper Agent CN](https://github.com/deepleaper/leaper-agent-cn)

## 🖥️ Supported Platforms

| Platform | Status |
|----------|--------|
| macOS (Apple Silicon) | ✅ Recommended |
| macOS (Intel) | ✅ |
| Linux (x86_64) | ✅ |
| Windows 10/11 | ✅ |

## 📄 License

[BSL-1.1](LICENSE) — see LICENSE for details.

## 🤝 Contributing

We welcome contributions! See [CONTRIBUTING.md](CONTRIBUTING.md).

📧 Questions? [tech@deepleaper.com](mailto:tech@deepleaper.com)

---

<div align="center">

**Built with ❤️ by [Deepleaper Technology / 跃盟科技](https://www.deepleaper.com)**

*Local AI that remembers. Private AI that evolves.*

</div>
